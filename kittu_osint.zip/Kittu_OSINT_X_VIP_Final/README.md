# Kittu OSINT X — VIP Edition

## Data storage
- **Bot DB (Turso):** users, VIP, credits, contacts, TG↔num, settings, logs
- **External OSINT DBs (VPS/RDP):** max 20 files × 3 GB each

## Run
```bash
pip install -r requirements.txt
# set env or edit bot.py defaults
python3 bot.py
```

## Env
See `.env.example` — especially `TURSO_DATABASE_URL` + `TURSO_AUTH_TOKEN`.
